# fingersUp-OpenCV

First upload code standard firmata Arduino (Serial)
Open IDE Arduino -> File -> Examples -> Firmata -> StandardFirmata
